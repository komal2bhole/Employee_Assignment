package com.empfinal2.EMPfinal2.Controller;

import com.empfinal2.EMPfinal2.Entity.Tax;
import com.empfinal2.EMPfinal2.Service.TaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tax")
public class TaxController {

    @Autowired
    private TaxService taxService;

    @GetMapping("/compute/{employeeId}")
    public ResponseEntity<Tax> computeYearlyTax(@PathVariable Long employeeId) {
        Tax tax = taxService.computeYearlyTax(employeeId);
        return ResponseEntity.ok(tax);
    }
}