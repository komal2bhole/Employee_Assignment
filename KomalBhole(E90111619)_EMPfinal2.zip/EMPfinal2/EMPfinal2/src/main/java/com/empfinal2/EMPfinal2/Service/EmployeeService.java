package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.DTO.EmployeeDTO;
import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee createOrUpdateEmployee(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setName(employeeDTO.getName());
        employee.setDepartment(employeeDTO.getDepartment());
        employee.setBasicSalary(employeeDTO.getBasicSalary());
        employee.setHra(employeeDTO.getHra());
        employee.setMedicalAllowance(employeeDTO.getMedicalAllowance());
        employee.setConveyance(employeeDTO.getConveyance());
        employee.setRelocationTax(employeeDTO.getRelocationTax());
        employee.setPf(employeeDTO.getPf());
        employee.setProfessionalTax(employeeDTO.getProfessionalTax());

        return employeeRepository.save(employee);
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }


    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }


}