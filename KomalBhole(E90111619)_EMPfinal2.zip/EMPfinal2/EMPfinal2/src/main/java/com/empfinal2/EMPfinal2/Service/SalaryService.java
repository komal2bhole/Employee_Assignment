package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import com.empfinal2.EMPfinal2.Repository.SalaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Optional;
@Service
public class SalaryService {

    @Autowired
    private SalaryRepository salaryRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public Salary getSalaryById(Long employeeId) {
        Optional<Salary> salaryOptional = salaryRepository.findByEmployeeId(employeeId);
        return salaryOptional.orElseThrow(() -> new RuntimeException("Salary not found for Employee ID: " + employeeId));
    }


    public Salary generateMonthlyPaycheck(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElseThrow(() -> new RuntimeException("Employee not found"));

        Double grossPay = employee.getBasicSalary() + employee.getHra() + employee.getMedicalAllowance() + employee.getConveyance();
        Double deductions = employee.getPf() + employee.getProfessionalTax();
        Double netPay = grossPay - deductions;

        Salary salary = new Salary();
        salary.setEmployee(employee);
        salary.setGrossPay(grossPay);
        salary.setNetPay(netPay);

        return salaryRepository.save(salary);
    }

}