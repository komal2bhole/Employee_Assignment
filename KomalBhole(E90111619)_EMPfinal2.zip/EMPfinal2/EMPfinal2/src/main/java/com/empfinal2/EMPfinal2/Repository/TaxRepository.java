package com.empfinal2.EMPfinal2.Repository;

import com.empfinal2.EMPfinal2.Entity.Tax;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaxRepository extends JpaRepository<Tax, Long> {
}
