package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Entity.Tax;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import com.empfinal2.EMPfinal2.Repository.SalaryRepository;
import com.empfinal2.EMPfinal2.Repository.TaxRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaxService {

    @Autowired
    private TaxRepository taxRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private SalaryRepository salaryRepository;

    public Tax computeYearlyTax(Long employeeId) {

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));


        Salary salary = salaryRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new RuntimeException("Salary details not found for the employee"));

        System.out.println("Gross"+salary.getGrossPay());


        Double grossSalary = salary.getGrossPay()*12;

        Double yearlyTax = 0.0;

        if (grossSalary <= 250000) {
            yearlyTax = 0.0;
        } else if (grossSalary <= 500000) {
            yearlyTax = (grossSalary - 250000) * 0.05;
        } else if (grossSalary <= 1000000) {
            yearlyTax = (500000 - 250000) * 0.05;
            yearlyTax += (grossSalary - 500000) * 0.20;
        } else {
            yearlyTax = (500000 - 250000) * 0.05;
            yearlyTax += (1000000 - 500000) * 0.20;
            yearlyTax += (grossSalary - 1000000) * 0.30;
        }

        Tax tax = new Tax();
        tax.setEmployee(employee);
        tax.setTaxAmount(yearlyTax);
        return taxRepository.save(tax);
    }
}
