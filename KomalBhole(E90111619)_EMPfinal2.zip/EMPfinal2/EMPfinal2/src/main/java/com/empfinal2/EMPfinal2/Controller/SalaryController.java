package com.empfinal2.EMPfinal2.Controller;

import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/salary")
public class SalaryController {

    @Autowired
    private SalaryService salaryService;

    @PostMapping("/generate/{employeeId}")
    public ResponseEntity<Salary> generatePaycheck(@PathVariable Long employeeId) {
        Salary salary = salaryService.generateMonthlyPaycheck(employeeId);
        return ResponseEntity.ok(salary);
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<Salary>getSalaryById(@PathVariable Long employeeId){
        Salary salary = salaryService.generateMonthlyPaycheck(employeeId);
        return ResponseEntity.ok(salary);
    }

}