package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.DTO.EmployeeDTO;
import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class EmployeeServiceTest {

    @InjectMocks
    private EmployeeService employeeService;

    @Mock
    private EmployeeRepository employeeRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateOrUpdateEmployee() {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setName("John Doe");
        employeeDTO.setDepartment("IT");
        employeeDTO.setBasicSalary(50000.0);
        employeeDTO.setHra(5000.0);
        employeeDTO.setMedicalAllowance(3000.0);
        employeeDTO.setConveyance(2000.0);
        employeeDTO.setRelocationTax(1500.0);
        employeeDTO.setPf(2000.0);
        employeeDTO.setProfessionalTax(1000.0);

        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setDepartment("IT");
        employee.setBasicSalary(50000.0);
        employee.setHra(5000.0);
        employee.setMedicalAllowance(3000.0);
        employee.setConveyance(2000.0);
        employee.setRelocationTax(1500.0);
        employee.setPf(2000.0);
        employee.setProfessionalTax(1000.0);

        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

        Employee savedEmployee = employeeService.createOrUpdateEmployee(employeeDTO);

        assertEquals("John Doe", savedEmployee.getName());
        assertEquals("IT", savedEmployee.getDepartment());
        assertEquals(50000.0, savedEmployee.getBasicSalary());
        verify(employeeRepository, times(1)).save(any(Employee.class));
    }

    @Test
    public void testGetEmployeeById_Found() {
        Long employeeId = 1L;
        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setName("Jane Doe");

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));

        Employee foundEmployee = employeeService.getEmployeeById(employeeId);

        assertEquals(employeeId, foundEmployee.getId());
        assertEquals("Jane Doe", foundEmployee.getName());
        verify(employeeRepository, times(1)).findById(employeeId);
    }

    @Test
    public void testGetEmployeeById_NotFound() {
        Long employeeId = 1L;

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.empty());

        Employee foundEmployee = employeeService.getEmployeeById(employeeId);

        assertNull(foundEmployee);
        verify(employeeRepository, times(1)).findById(employeeId);
    }

    @Test
    public void testGetAllEmployees() {
        List<Employee> employees = Arrays.asList(new Employee(), new Employee());
        when(employeeRepository.findAll()).thenReturn(employees);

        List<Employee> foundEmployees = employeeService.getAllEmployees();

        assertEquals(2, foundEmployees.size());
        verify(employeeRepository, times(1)).findAll();
    }

    @Test
    public void testDeleteEmployee() {
        Long employeeId = 1L;

        doNothing().when(employeeRepository).deleteById(employeeId);

        employeeService.deleteEmployee(employeeId);

        verify(employeeRepository, times(1)).deleteById(employeeId);
    }
}