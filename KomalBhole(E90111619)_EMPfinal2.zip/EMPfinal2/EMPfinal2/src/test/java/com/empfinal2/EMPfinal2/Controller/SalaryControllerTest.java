package com.empfinal2.EMPfinal2.Controller;

import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Service.SalaryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class SalaryControllerTest {

    @Mock
    private SalaryService salaryService;

    @InjectMocks
    private SalaryController salaryController;

    private Salary salary;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        salary = new Salary();
        salary.setGrossPay(60000.00);
    }

    @Test
    void testGeneratePaycheck() {
        // Arrange
        when(salaryService.generateMonthlyPaycheck(anyLong())).thenReturn(salary);

        ResponseEntity<Salary> response = salaryController.generatePaycheck(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(salary, response.getBody());
        verify(salaryService, times(1)).generateMonthlyPaycheck(1L);
    }

    @Test
    void testGetSalaryById() {

        when(salaryService.generateMonthlyPaycheck(anyLong())).thenReturn(salary);

        ResponseEntity<Salary> response = salaryController.getSalaryById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(salary, response.getBody());
        verify(salaryService, times(1)).generateMonthlyPaycheck(1L);
    }
}