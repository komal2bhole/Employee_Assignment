package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import com.empfinal2.EMPfinal2.Repository.SalaryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SalaryServiceTest {

    @Mock
    private SalaryRepository salaryRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private SalaryService salaryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getSalaryById_ExistingEmployeeId_ReturnsSalary() {
        Long employeeId = 1L;
        Salary mockSalary = new Salary();
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.of(mockSalary));

        Salary salary = salaryService.getSalaryById(employeeId);

        assertNotNull(salary);
        assertEquals(mockSalary, salary);
        verify(salaryRepository, times(1)).findByEmployeeId(employeeId);
    }

    @Test
    void getSalaryById_NonExistingEmployeeId_ThrowsException() {
        Long employeeId = 1L;
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> salaryService.getSalaryById(employeeId));

        assertEquals("Salary not found for Employee ID: " + employeeId, exception.getMessage());
        verify(salaryRepository, times(1)).findByEmployeeId(employeeId);
    }

    @Test
    void generateMonthlyPaycheck_ExistingEmployeeId_ReturnsGeneratedSalary() {
        Long employeeId = 1L;
        Employee mockEmployee = new Employee();
        mockEmployee.setBasicSalary(50000.0);
        mockEmployee.setHra(10000.0);
        mockEmployee.setMedicalAllowance(5000.0);
        mockEmployee.setConveyance(2000.0);
        mockEmployee.setPf(5000.0);
        mockEmployee.setProfessionalTax(2000.0);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(mockEmployee));

        Salary mockSalary = new Salary();
        mockSalary.setEmployee(mockEmployee);  // Set the employee in the mock salary
        mockSalary.setGrossPay(67000.0);
        mockSalary.setNetPay(60000.0);

        when(salaryRepository.save(any(Salary.class))).thenReturn(mockSalary);

        Salary salary = salaryService.generateMonthlyPaycheck(employeeId);

        assertNotNull(salary);
        assertEquals(mockEmployee, salary.getEmployee());  // Check that the employee is set
        assertEquals(67000.0, salary.getGrossPay());  // Check gross pay
        assertEquals(60000.0, salary.getNetPay());  // Check net pay

        verify(employeeRepository, times(1)).findById(employeeId);
        verify(salaryRepository, times(1)).save(any(Salary.class));
    }

    @Test
    void generateMonthlyPaycheck_NonExistingEmployeeId_ThrowsException() {
        Long employeeId = 1L;
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> salaryService.generateMonthlyPaycheck(employeeId));

        assertEquals("Employee not found", exception.getMessage());
        verify(employeeRepository, times(1)).findById(employeeId);
        verify(salaryRepository, times(0)).save(any(Salary.class));
    }
}