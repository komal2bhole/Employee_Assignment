package com.empfinal2.EMPfinal2.Service;

import com.empfinal2.EMPfinal2.Entity.Employee;
import com.empfinal2.EMPfinal2.Entity.Salary;
import com.empfinal2.EMPfinal2.Entity.Tax;
import com.empfinal2.EMPfinal2.Repository.EmployeeRepository;
import com.empfinal2.EMPfinal2.Repository.SalaryRepository;
import com.empfinal2.EMPfinal2.Repository.TaxRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class TaxServiceTest {

    @InjectMocks
    private TaxService taxService;

    @Mock
    private TaxRepository taxRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private SalaryRepository salaryRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void computeYearlyTax_ShouldReturnCorrectTaxForEmployeeInLowestTaxBracket() {
        Long employeeId = 1L;

        Employee employee = new Employee();
        employee.setId(employeeId);

        Salary salary = new Salary();
        salary.setGrossPay(20000.0);

        Tax savedTax = new Tax();
        savedTax.setEmployee(employee);
        savedTax.setTaxAmount(0.0);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.of(salary));
        when(taxRepository.save(any(Tax.class))).thenReturn(savedTax);

        Tax tax = taxService.computeYearlyTax(employeeId);

        assertEquals(0.0, tax.getTaxAmount());
        verify(taxRepository, times(1)).save(any(Tax.class));
    }

    @Test
    void computeYearlyTax_ShouldReturnCorrectTaxForEmployeeInSecondTaxBracket() {
        Long employeeId = 2L;

        Employee employee = new Employee();
        employee.setId(employeeId);

        Salary salary = new Salary();
        salary.setGrossPay(40000.0);


        Tax savedTax = new Tax();
        savedTax.setEmployee(employee);
        savedTax.setTaxAmount(11500.0);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.of(salary));
        when(taxRepository.save(any(Tax.class))).thenReturn(savedTax);

        Tax tax = taxService.computeYearlyTax(employeeId);

        assertEquals(11500.0, tax.getTaxAmount()); // Verify tax amount
        verify(taxRepository, times(1)).save(any(Tax.class));
    }

    @Test
    void computeYearlyTax_ShouldReturnCorrectTaxForEmployeeInHighestTaxBracket() {
        Long employeeId = 3L;

        Employee employee = new Employee();
        employee.setId(employeeId);

        Salary salary = new Salary();
        salary.setGrossPay(80000.0);

        Tax savedTax = new Tax();
        savedTax.setEmployee(employee);
        savedTax.setTaxAmount(68500.0);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.of(salary));
        when(taxRepository.save(any(Tax.class))).thenReturn(savedTax);

        Tax tax = taxService.computeYearlyTax(employeeId);

        assertEquals(68500.0, tax.getTaxAmount());
        verify(taxRepository, times(1)).save(any(Tax.class));
    }

    @Test
    void computeYearlyTax_ShouldThrowExceptionWhenEmployeeNotFound() {
        Long employeeId = 5L;

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> taxService.computeYearlyTax(employeeId));

        assertEquals("Employee not found", exception.getMessage());
        verify(taxRepository, never()).save(any(Tax.class));
    }

    @Test
    void computeYearlyTax_ShouldThrowExceptionWhenSalaryNotFound() {
        Long employeeId = 6L;

        Employee employee = new Employee();
        employee.setId(employeeId);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(salaryRepository.findByEmployeeId(employeeId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> taxService.computeYearlyTax(employeeId));

        assertEquals("Salary details not found for the employee", exception.getMessage());
        verify(taxRepository, never()).save(any(Tax.class));
    }
}