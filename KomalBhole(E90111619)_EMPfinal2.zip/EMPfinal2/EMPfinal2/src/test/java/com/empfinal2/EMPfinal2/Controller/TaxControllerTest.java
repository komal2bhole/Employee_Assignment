package com.empfinal2.EMPfinal2.Controller;

import com.empfinal2.EMPfinal2.Entity.Tax;
import com.empfinal2.EMPfinal2.Service.TaxService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class TaxControllerTest {

    @InjectMocks
    private TaxController taxController;

    @Mock
    private TaxService taxService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testComputeYearlyTax() {
        // Given
        Long employeeId = 1L;
        Tax mockTax = new Tax();
        mockTax.setTaxId(1L);
        mockTax.setEmployeeId(employeeId);
        mockTax.setTaxAmount(5000.0); // Example tax amount

        when(taxService.computeYearlyTax(employeeId)).thenReturn(mockTax);
        ResponseEntity<Tax> response = taxController.computeYearlyTax(employeeId);

        assertEquals(ResponseEntity.ok(mockTax), response);
        assertEquals(mockTax.getTaxAmount(), response.getBody().getTaxAmount());

    }
}
